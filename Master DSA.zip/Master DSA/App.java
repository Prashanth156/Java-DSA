public class App {
    public static void main(String[] args) {
    
        SinglyLinkedList q= new SinglyLinkedList();

        q.insertFront(10);
        q.insertFront(20);
        q.insertFront(30);
        q.display();
        q.insertEnd(40);
        q.display();
        q.delete(20);
        q.display();
            


        

       
        

    }
}